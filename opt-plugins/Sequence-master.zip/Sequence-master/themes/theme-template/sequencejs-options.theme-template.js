$(document).ready(function() {
    var options = {
        nextButton: true,
        prevButton: true
    };

    var sequence = $("#sequence").sequence(options).data("sequence");
});