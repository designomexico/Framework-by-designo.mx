$(document).ready(function() {
    var options = {
        navigationSkip: false
    };

    var sequence = $("#sequence").sequence(options).data("sequence");
});